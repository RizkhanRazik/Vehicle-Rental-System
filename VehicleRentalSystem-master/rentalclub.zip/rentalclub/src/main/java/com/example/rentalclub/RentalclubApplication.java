package com.example.rentalclub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class RentalclubApplication {


    public static void main(String[] args) {
        SpringApplication.run(RentalclubApplication.class, args);
    }


}
